package com.example.demo.services;

import com.example.demo.domain.Course;
import com.example.demo.domain.Student;
import com.example.demo.repositories.CourseRepo;
import org.springframework.beans.factory.annotation.Autowired;

public class CourseService {
    @Autowired
    private CourseRepo courseRepo;




}
